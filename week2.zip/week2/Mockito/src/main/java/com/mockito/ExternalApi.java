package com.mockito;

public interface ExternalApi {
    String getData();
}
