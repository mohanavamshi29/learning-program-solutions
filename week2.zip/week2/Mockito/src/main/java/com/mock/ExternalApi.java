package com.mock;

public interface ExternalApi {
    String getData();
}
