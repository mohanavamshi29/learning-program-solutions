UPDATE Customers
SET IsVIP = 'Y'
WHERE Balance > 10000;

SELECT * FROM Customers;
